function showFox() {
    // your code here...
    console.log('Change image and paragraph to fox...');
    const template = `
    <img src="images/fox.jpg"/>
    <p>Fox</p>`;
    document.querySelector('.card').innerHTML = template;
}

function showLion() {
    // your code here...
    console.log('Change image and paragraph to lion...');
    const template = `
    <img src="images/lion.jpg"/>
    <p>Lion</p>`;
    document.querySelector('.card').innerHTML = template;
}

function showTiger() {
    // your code here...
    console.log('Change image and paragraph to tiger...');
    const template = `
    <img src="images/tiger.png"/>
    <p>Tiger</p>`;
    document.querySelector('.card').innerHTML = template;
}

function showZebra() {
    // your code here...
    console.log('Change image and paragraph to zebra...');
    const template = `
    <img src="images/zebra.jpg"/>
    <p>Zebra</p>`;
    document.querySelector('.card').innerHTML = template;
}

